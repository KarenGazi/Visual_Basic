﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBoxName = New System.Windows.Forms.TextBox()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.LabelName = New System.Windows.Forms.Label()
        Me.LabelSurname = New System.Windows.Forms.Label()
        Me.TextBoxSurname = New System.Windows.Forms.TextBox()
        Me.LabelDNum = New System.Windows.Forms.Label()
        Me.TextBoxID = New System.Windows.Forms.TextBox()
        Me.LabelOcc = New System.Windows.Forms.Label()
        Me.TextBoxOcc = New System.Windows.Forms.TextBox()
        Me.LabelAge = New System.Windows.Forms.Label()
        Me.TextBoxAge = New System.Windows.Forms.TextBox()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.LabelAddr = New System.Windows.Forms.Label()
        Me.TextBoxAddr = New System.Windows.Forms.TextBox()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.LabelVModel = New System.Windows.Forms.Label()
        Me.LabelVRN = New System.Windows.Forms.Label()
        Me.LabelVColor = New System.Windows.Forms.Label()
        Me.TextBoxVColor = New System.Windows.Forms.TextBox()
        Me.TextBoxVModel = New System.Windows.Forms.TextBox()
        Me.TextBoxVRN = New System.Windows.Forms.TextBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.RadioButtonMale = New System.Windows.Forms.RadioButton()
        Me.RadioButtonFemale = New System.Windows.Forms.RadioButton()
        Me.ButtonSubmit = New System.Windows.Forms.Button()
        Me.ButtonCancel = New System.Windows.Forms.Button()
        Me.GroupBoxSex = New System.Windows.Forms.GroupBox()
        Me.GroupBoxSex.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBoxName
        '
        Me.TextBoxName.Location = New System.Drawing.Point(173, 83)
        Me.TextBoxName.Name = "TextBoxName"
        Me.TextBoxName.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxName.TabIndex = 0
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(105, 23)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(213, 13)
        Me.lbl1.TabIndex = 1
        Me.lbl1.Text = "CAR INSURANCE REGISTRATION FORM" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'LabelName
        '
        Me.LabelName.AutoSize = True
        Me.LabelName.Location = New System.Drawing.Point(73, 83)
        Me.LabelName.Name = "LabelName"
        Me.LabelName.Size = New System.Drawing.Size(35, 13)
        Me.LabelName.TabIndex = 2
        Me.LabelName.Text = "Name"
        '
        'LabelSurname
        '
        Me.LabelSurname.AutoSize = True
        Me.LabelSurname.Location = New System.Drawing.Point(73, 128)
        Me.LabelSurname.Name = "LabelSurname"
        Me.LabelSurname.Size = New System.Drawing.Size(49, 13)
        Me.LabelSurname.TabIndex = 3
        Me.LabelSurname.Text = "Surname"
        '
        'TextBoxSurname
        '
        Me.TextBoxSurname.Location = New System.Drawing.Point(173, 125)
        Me.TextBoxSurname.Name = "TextBoxSurname"
        Me.TextBoxSurname.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxSurname.TabIndex = 4
        '
        'LabelDNum
        '
        Me.LabelDNum.AutoSize = True
        Me.LabelDNum.Location = New System.Drawing.Point(73, 260)
        Me.LabelDNum.Name = "LabelDNum"
        Me.LabelDNum.Size = New System.Drawing.Size(58, 13)
        Me.LabelDNum.TabIndex = 5
        Me.LabelDNum.Text = "ID Number"
        '
        'TextBoxID
        '
        Me.TextBoxID.Location = New System.Drawing.Point(173, 253)
        Me.TextBoxID.Name = "TextBoxID"
        Me.TextBoxID.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxID.TabIndex = 6
        '
        'LabelOcc
        '
        Me.LabelOcc.AutoSize = True
        Me.LabelOcc.Location = New System.Drawing.Point(69, 340)
        Me.LabelOcc.Name = "LabelOcc"
        Me.LabelOcc.Size = New System.Drawing.Size(62, 13)
        Me.LabelOcc.TabIndex = 7
        Me.LabelOcc.Text = "Occupation"
        '
        'TextBoxOcc
        '
        Me.TextBoxOcc.Location = New System.Drawing.Point(173, 333)
        Me.TextBoxOcc.Name = "TextBoxOcc"
        Me.TextBoxOcc.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxOcc.TabIndex = 8
        '
        'LabelAge
        '
        Me.LabelAge.AutoSize = True
        Me.LabelAge.Location = New System.Drawing.Point(73, 300)
        Me.LabelAge.Name = "LabelAge"
        Me.LabelAge.Size = New System.Drawing.Size(26, 13)
        Me.LabelAge.TabIndex = 9
        Me.LabelAge.Text = "Age"
        '
        'TextBoxAge
        '
        Me.TextBoxAge.Location = New System.Drawing.Point(173, 293)
        Me.TextBoxAge.Name = "TextBoxAge"
        Me.TextBoxAge.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxAge.TabIndex = 10
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(145, 47)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(113, 13)
        Me.lbl2.TabIndex = 11
        Me.lbl2.Text = "PERSONAL DETAILS"
        '
        'LabelAddr
        '
        Me.LabelAddr.AutoSize = True
        Me.LabelAddr.Location = New System.Drawing.Point(69, 378)
        Me.LabelAddr.Name = "LabelAddr"
        Me.LabelAddr.Size = New System.Drawing.Size(45, 13)
        Me.LabelAddr.TabIndex = 12
        Me.LabelAddr.Text = "Address"
        '
        'TextBoxAddr
        '
        Me.TextBoxAddr.Location = New System.Drawing.Point(173, 371)
        Me.TextBoxAddr.Name = "TextBoxAddr"
        Me.TextBoxAddr.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxAddr.TabIndex = 13
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Location = New System.Drawing.Point(145, 414)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(100, 13)
        Me.lbl3.TabIndex = 14
        Me.lbl3.Text = "VEHICLE DETAILS"
        '
        'LabelVModel
        '
        Me.LabelVModel.AutoSize = True
        Me.LabelVModel.Location = New System.Drawing.Point(73, 495)
        Me.LabelVModel.Name = "LabelVModel"
        Me.LabelVModel.Size = New System.Drawing.Size(74, 13)
        Me.LabelVModel.TabIndex = 15
        Me.LabelVModel.Text = "Vehicle Model"
        '
        'LabelVRN
        '
        Me.LabelVRN.AutoSize = True
        Me.LabelVRN.Location = New System.Drawing.Point(73, 458)
        Me.LabelVRN.Name = "LabelVRN"
        Me.LabelVRN.Size = New System.Drawing.Size(141, 13)
        Me.LabelVRN.TabIndex = 16
        Me.LabelVRN.Text = "Vehicle-Registration Number"
        '
        'LabelVColor
        '
        Me.LabelVColor.AutoSize = True
        Me.LabelVColor.Location = New System.Drawing.Point(73, 532)
        Me.LabelVColor.Name = "LabelVColor"
        Me.LabelVColor.Size = New System.Drawing.Size(69, 13)
        Me.LabelVColor.TabIndex = 17
        Me.LabelVColor.Text = "Vehicle Color"
        '
        'TextBoxVColor
        '
        Me.TextBoxVColor.Location = New System.Drawing.Point(237, 529)
        Me.TextBoxVColor.Name = "TextBoxVColor"
        Me.TextBoxVColor.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxVColor.TabIndex = 18
        '
        'TextBoxVModel
        '
        Me.TextBoxVModel.Location = New System.Drawing.Point(237, 488)
        Me.TextBoxVModel.Name = "TextBoxVModel"
        Me.TextBoxVModel.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxVModel.TabIndex = 19
        '
        'TextBoxVRN
        '
        Me.TextBoxVRN.Location = New System.Drawing.Point(237, 451)
        Me.TextBoxVRN.Name = "TextBoxVRN"
        Me.TextBoxVRN.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxVRN.TabIndex = 20
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(173, 562)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(282, 17)
        Me.CheckBox1.TabIndex = 21
        Me.CheckBox1.Text = "I agree to the terms and conditions of signing this form."
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'RadioButtonMale
        '
        Me.RadioButtonMale.AutoSize = True
        Me.RadioButtonMale.Location = New System.Drawing.Point(23, 19)
        Me.RadioButtonMale.Name = "RadioButtonMale"
        Me.RadioButtonMale.Size = New System.Drawing.Size(48, 17)
        Me.RadioButtonMale.TabIndex = 22
        Me.RadioButtonMale.TabStop = True
        Me.RadioButtonMale.Text = "Male"
        Me.RadioButtonMale.UseVisualStyleBackColor = True
        '
        'RadioButtonFemale
        '
        Me.RadioButtonFemale.AutoSize = True
        Me.RadioButtonFemale.Location = New System.Drawing.Point(23, 43)
        Me.RadioButtonFemale.Name = "RadioButtonFemale"
        Me.RadioButtonFemale.Size = New System.Drawing.Size(59, 17)
        Me.RadioButtonFemale.TabIndex = 23
        Me.RadioButtonFemale.TabStop = True
        Me.RadioButtonFemale.Text = "Female"
        Me.RadioButtonFemale.UseVisualStyleBackColor = True
        '
        'ButtonSubmit
        '
        Me.ButtonSubmit.Location = New System.Drawing.Point(183, 619)
        Me.ButtonSubmit.Name = "ButtonSubmit"
        Me.ButtonSubmit.Size = New System.Drawing.Size(75, 23)
        Me.ButtonSubmit.TabIndex = 24
        Me.ButtonSubmit.Text = "Submit"
        Me.ButtonSubmit.UseVisualStyleBackColor = True
        '
        'ButtonCancel
        '
        Me.ButtonCancel.Location = New System.Drawing.Point(303, 619)
        Me.ButtonCancel.Name = "ButtonCancel"
        Me.ButtonCancel.Size = New System.Drawing.Size(75, 23)
        Me.ButtonCancel.TabIndex = 25
        Me.ButtonCancel.Text = "Cancel"
        Me.ButtonCancel.UseVisualStyleBackColor = True
        '
        'GroupBoxSex
        '
        Me.GroupBoxSex.Controls.Add(Me.RadioButtonMale)
        Me.GroupBoxSex.Controls.Add(Me.RadioButtonFemale)
        Me.GroupBoxSex.Location = New System.Drawing.Point(148, 169)
        Me.GroupBoxSex.Name = "GroupBoxSex"
        Me.GroupBoxSex.Size = New System.Drawing.Size(200, 66)
        Me.GroupBoxSex.TabIndex = 26
        Me.GroupBoxSex.TabStop = False
        Me.GroupBoxSex.Text = "Sex"
        '
        'VBYangu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(722, 645)
        Me.Controls.Add(Me.GroupBoxSex)
        Me.Controls.Add(Me.ButtonCancel)
        Me.Controls.Add(Me.ButtonSubmit)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.TextBoxVRN)
        Me.Controls.Add(Me.TextBoxVModel)
        Me.Controls.Add(Me.TextBoxVColor)
        Me.Controls.Add(Me.LabelVColor)
        Me.Controls.Add(Me.LabelVRN)
        Me.Controls.Add(Me.LabelVModel)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.TextBoxAddr)
        Me.Controls.Add(Me.LabelAddr)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.TextBoxAge)
        Me.Controls.Add(Me.LabelAge)
        Me.Controls.Add(Me.TextBoxOcc)
        Me.Controls.Add(Me.LabelOcc)
        Me.Controls.Add(Me.TextBoxID)
        Me.Controls.Add(Me.LabelDNum)
        Me.Controls.Add(Me.TextBoxSurname)
        Me.Controls.Add(Me.LabelSurname)
        Me.Controls.Add(Me.LabelName)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.TextBoxName)
        Me.Name = "VBYangu"
        Me.Text = "Car Insurance Information Form"
        Me.GroupBoxSex.ResumeLayout(False)
        Me.GroupBoxSex.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBoxName As System.Windows.Forms.TextBox
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents LabelName As System.Windows.Forms.Label
    Friend WithEvents LabelSurname As System.Windows.Forms.Label
    Friend WithEvents TextBoxSurname As System.Windows.Forms.TextBox
    Friend WithEvents LabelDNum As System.Windows.Forms.Label
    Friend WithEvents TextBoxID As System.Windows.Forms.TextBox
    Friend WithEvents LabelOcc As System.Windows.Forms.Label
    Friend WithEvents TextBoxOcc As System.Windows.Forms.TextBox
    Friend WithEvents LabelAge As System.Windows.Forms.Label
    Friend WithEvents TextBoxAge As System.Windows.Forms.TextBox
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents LabelAddr As System.Windows.Forms.Label
    Friend WithEvents TextBoxAddr As System.Windows.Forms.TextBox
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents LabelVModel As System.Windows.Forms.Label
    Friend WithEvents LabelVRN As System.Windows.Forms.Label
    Friend WithEvents LabelVColor As System.Windows.Forms.Label
    Friend WithEvents TextBoxVColor As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxVModel As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxVRN As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButtonMale As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonFemale As System.Windows.Forms.RadioButton
    Friend WithEvents ButtonSubmit As System.Windows.Forms.Button
    Friend WithEvents ButtonCancel As System.Windows.Forms.Button
    Friend WithEvents GroupBoxSex As System.Windows.Forms.GroupBox

End Class
