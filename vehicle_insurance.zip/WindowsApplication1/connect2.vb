﻿Imports System.Convert
Imports MySql.Data.MySqlClient
Module connect2
    Sub Connection()
        Dim connectionString As String
        Dim sotConn As New MySqlConnection
        connectionString = "server=localhost;userid=root;database=vehicle_insurance"
        sotConn.ConnectionString = connectionString
        Try
            sotConn.Open()

        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try

    End Sub
    Function SotConnection() As MySqlConnection
        Dim connectionString As String
        Dim sotConn As New MySqlConnection
        connectionString = "server=localhost;userid=root;database=vehicle_insurance"
        sotConn.ConnectionString = connectionString
        Try
            sotConn.Open()
            MsgBox("connected")
        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try
        Return sotConn
    End Function
    Sub SaveClient()

        Dim Name As String
        Dim Surname As String
        'Dim ID Number As Integer
        Dim Sex As String
        Dim Age As Integer
        Dim Occupation As String
        Dim Address As String
        ' Dim Vehicle Model As String


        Dim cmd As New MySqlCommand
        Dim sqlString As String
        With mainform
            Name = TextBoxName.Text
            If RadioButtonMale.Checked Then
                Sex = "Male"
            Else
                Sex = "Female"
            End If
        End With

        sqlString = "INSERT INTO vehicle_insurance VALUES('" & _
            Name & "','" & Surname & "','" & Sex & "','" & Age &"','" &)"

        With cmd
            .Connection = SotConnection()
            .CommandText = sqlString
            .CommandType = CommandType.Text
            .ExecuteNonQuery()
        End With
        MsgBox("Client Saved")

    End Sub

End Module
