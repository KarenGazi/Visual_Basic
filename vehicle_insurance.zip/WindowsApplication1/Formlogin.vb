﻿Public Class FormLoginSystem

   

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.

    Private Sub ButtonLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonLogin.Click

        If TextBoxUsername.Text = "abc" And TextBoxPassword.Text = "xyz" Then
            Me.Hide()
            mainform.Show()

        Else
            MsgBox("Wrong Username or Password")


        End If
    End Sub

    Private Sub ButtonCancel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonCancel2.Click
        Me.Close()
    End Sub

    Private Sub FormLoginSystem_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


End Class