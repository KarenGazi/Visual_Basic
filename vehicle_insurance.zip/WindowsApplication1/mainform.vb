﻿Public Class mainform

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles ButtonSubmit.Click
        Dim Name As String
        Dim Surname As String
        'Dim ID Number As Integer
        Dim Sex As String
        Dim Age As Integer
        Dim Occupation As String
        Dim Address As String
        ' Dim Vehicle Model As String


        If TextBoxName.Text = "" Then
            MsgBox("Name cannot be empty")
            TextBoxName.Focus()
        Else
            Name = TextBoxName.Text
        End If

        If TextBoxSurname.Text = "" Then
            MsgBox("Surname cannot be empty")
            TextBoxSurname.Focus()
        Else
            Surname = TextBoxSurname.Text
        End If

        If RadioButtonMale.Checked = False And RadioButtonFemale.Checked = False Then
            MsgBox("Please check male or female")
        ElseIf RadioButtonFemale.Checked = True Then
            Sex = "female"
        ElseIf RadioButtonMale.Checked = True Then
            Sex = "male"
        End If

        If TextBoxID.Text = "" Then
            MsgBox("ID Number cannot be empty")
            TextBoxID.Focus()
        Else
            ' ID Number = TextBoxID.Text
        End If


        If TextBoxVModel.Text = "" Then
            MsgBox("Vehicle model cannot be empty")
            TextBoxVModel.Focus()
        Else
            'Vehicle Model = TextBoxID.Text
        End If


    End Sub

    Private Sub LabelName_Click(sender As Object, e As EventArgs) Handles LabelName.Click

    End Sub

    Private Sub LabelSurname_Click(sender As Object, e As EventArgs) Handles lbl2.Click

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles ButtonSubmit.Click

    End Sub

    Private Sub VBYangu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
