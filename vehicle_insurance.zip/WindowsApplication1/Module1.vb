﻿Imports MySql.Data.MySqlClient

Module UtilitiesModule
    Public Sub connect()

        Dim connObject As New MySqlConnection
        Dim connString As String
        connString = "server=localhost; userid=tagz; password=12345; database=insurance"
        connObject.ConnectionString = connString
        Try
            connObject.Open()
            MsgBox("Connection Succesfull")
        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            connObject.Dispose()
        End Try
    End Sub

End Module
